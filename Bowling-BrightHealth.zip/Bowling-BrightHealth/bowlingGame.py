# calculate score
# display score
# play game abstract function
# computer automated or user input

import random

class Bowling:
    def __init__(self):
        self.frame = 1
        self.frames = [[] for i in range(10)]
        self.score = 0

    def roll(self):
        roll1 = random.randint(0, 10)
        self.checkspare(roll1)
        #roll1 = 3
        if roll1 < 10:
            roll2 = random.randint(0, 10 - roll1)
            self.checkstrike(roll1, roll2)
            #roll2 = 2
            if roll1 + roll2 == 10:
                self.spare(roll1, roll2)
            else:
                self.open(roll1, roll2)
        else:
            self.strike()

    def open(self, roll1, roll2):
        self.frames[self.frame - 1].append(roll1)
        self.frames[self.frame - 1].append(roll2)
        self.score += roll1 + roll2
        print(f'Current frames: {self.frames[0:self.frame]}\nCurrent Score: {self.score}')
        self.frame += 1
        return

    def spare(self, roll1, roll2):
        self.frames[self.frame - 1].append(roll1)
        self.frames[self.frame - 1].append('/')
        self.score += 10
        if self.frame == 10:
            lastRoll = random.randint(0, 10)
            self.frames[self.frame - 1].append(lastRoll)
            self.score += lastRoll
        else:
            print(f'Current frames: {self.frames[0:self.frame]}\nSpare!')
        self.frame += 1
        return

    def strike(self):
        self.frames[self.frame - 1].append('X')
        self.score += 10
        if self.frame == 10:
            lastRoll1 = random.randint(0, 10)
            lastRoll2 = random.randint(0, 10)
            self.frames[self.frame - 1].append(lastRoll1)
            self.frames[self.frame - 1].append(lastRoll2)
            self.score += lastRoll1 + lastRoll2
        else:
            print(f'Current frames: {self.frames[0:self.frame]}\nSTRIKE!')
        self.frame += 1
        return

    def checkspare(self, roll1):
        if self.frame == 1:
            pass
        else:
            if '/' in self.frames[self.frame - 2]:
                self.score += roll1
        return

    def checkstrike(self, roll1, roll2):
        if self.frame == 1:
            pass
        else:
            if 'X' in self.frames[self.frame - 2]:
                self.score += roll1 + roll2
        return

    def play(self):
        while self.frame <= 10:
            self.roll()
        print(f'You made it to the end! Congrats. Here is the final score: {self.score}')

